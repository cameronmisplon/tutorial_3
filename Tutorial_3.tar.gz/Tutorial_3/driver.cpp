#include <iostream>


int main(void)
{
	
	int a = 10;
	float b = 15.5;

	std::cout << "The address of variable 'a' is: " << &a << std::endl;
	std::cout << "The address of varialbe 'b' is: " << &b << std::endl;

	return 0;
}